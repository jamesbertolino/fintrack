'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase-browser'
import { usePerfil } from '@/hooks/usePerfil'

interface Transacao {
  id: string
  descricao: string
  valor: number
  tipo: 'debito' | 'credito'
  categoria: string
  data_hora: string
  origem: string
}

const CATEGORIAS_DESPESA = ['Alimentação','Transporte','Lazer','Saúde','Moradia','Educação','Outros']
const CATEGORIAS_RECEITA = ['Salário','Freelance','Investimento','Presente','Outros']

const CORES: Record<string, string> = {
  'Alimentação': '#4ade80', 'Transporte': '#22d3ee', 'Lazer': '#f97316',
  'Saúde': '#a78bfa', 'Moradia': '#fbbf24', 'Educação': '#60a5fa',
  'Salário': '#4ade80', 'Freelance': '#34d399', 'Investimento': '#818cf8',
  'Presente': '#f472b6', 'Outros': '#6b7280',
}

const ATALHOS = [
  { label: 'iFood',        cat: 'Alimentação', tipo: 'debito'  },
  { label: 'Uber',         cat: 'Transporte',  tipo: 'debito'  },
  { label: 'Mercado',      cat: 'Alimentação', tipo: 'debito'  },
  { label: 'Salário',      cat: 'Salário',     tipo: 'credito' },
  { label: 'Farmácia',     cat: 'Saúde',       tipo: 'debito'  },
  { label: 'Netflix',      cat: 'Lazer',       tipo: 'debito'  },
  { label: 'Luz/Água/Gás', cat: 'Moradia',     tipo: 'debito'  },
  { label: 'Freelance',    cat: 'Freelance',   tipo: 'credito' },
]

function fmtBRL(v: number) {
  return 'R$ ' + Math.abs(v).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
}

function dataLocalParaInput(timezone: string): string {
  const agora = new Date()
  const local = new Intl.DateTimeFormat('sv-SE', {
    timeZone: timezone,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  }).format(agora)
  return local.replace(' ', 'T').slice(0, 16)
}

function inputParaUTC(dataLocal: string, timezone: string): string {
  const [data, hora] = dataLocal.split('T')
  const [ano, mes, dia] = data.split('-').map(Number)
  const [h, min] = hora.split(':').map(Number)

  const dataObj = new Date(Date.UTC(ano, mes - 1, dia, h, min))
  const formatter = new Intl.DateTimeFormat('en', {
    timeZone: timezone,
    timeZoneName: 'shortOffset',
  })
  const parts = formatter.formatToParts(dataObj)
  const offset = parts.find(p => p.type === 'timeZoneName')?.value || 'GMT+0'
  const match = offset.match(/GMT([+-]\d+)(?::(\d+))?/)
  const horas = match ? parseInt(match[1]) : 0
  const mins  = match ? parseInt(match[2] || '0') : 0
  const offsetMs = (horas * 60 + (horas < 0 ? -mins : mins)) * 60000
  return new Date(dataObj.getTime() - offsetMs).toISOString()
}

export default function LancamentoPage() {
  const router = useRouter()
  const supabase = createClient()
  const { fmtDataHora } = usePerfil()

  const [tipo, setTipo]             = useState<'debito' | 'credito'>('debito')
  const [valor, setValor]           = useState('')
  const [descricao, setDescricao]   = useState('')
  const [categoria, setCategoria]   = useState('Alimentação')
  const [dataHora, setDataHora]     = useState('')
  const [timezone, setTimezone]     = useState('America/Sao_Paulo')
  const [recorrente, setRecorrente] = useState(false)
  const [salvando, setSalvando]     = useState(false)
  const [erro, setErro]             = useState('')
  const [sucesso, setSucesso]       = useState(false)
  const [historico, setHistorico]   = useState<Transacao[]>([])
  const [deletando, setDeletando]   = useState<string | null>(null)
  const [userId, setUserId]         = useState('')
  const [contas, setContas]         = useState<Array<{ id: string; nome: string; tipo: string; bancos: { id: string; nome_curto: string; cor: string | null } | null }>>([])
  const [contaSelecionada, setConta] = useState('')
  const [bancoDetectado, setBancoDetectado] = useState<{ id: string; nome_curto: string; cor: string | null } | null>(null)
  const [contaUpload, setContaUpload] = useState('')

  const inputRef                    = useRef<HTMLInputElement>(null)
  const [dragOver, setDragOver]     = useState(false)
  const [processando, setProcessan] = useState(false)
  const [confirmando, setConfirman] = useState(false)
  const [transacoesDetectadas, setTransacoesDetectadas] = useState<Array<{
    descricao: string; valor: number; tipo: string; categoria: string; data_hora: string
  }>>([])
  const [resumoDetectado, setResumo] = useState('')

  // Busca timezone do perfil e inicializa o campo de data/hora corretamente
  useEffect(() => {
    const client = createClient()
    client.auth.getUser().then(({ data: { user } }) => {
      if (!user) return
      client.from('profiles').select('timezone').eq('id', user.id).single().then(({ data }) => {
        const tz = data?.timezone || 'America/Sao_Paulo'
        setTimezone(tz)
        setDataHora(dataLocalParaInput(tz))
      })
    })
  }, [])

  // useCallback declarado ANTES do useEffect que o chama
  useEffect(() => {
    fetch('/api/contas').then(r => r.json()).then(d => setContas(d.contas || []))
  }, [])

  const carregarHistorico = useCallback(async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) { router.push('/login'); return }
    setUserId(user.id)

    const { data } = await supabase
      .from('transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('data_hora', { ascending: false })
      .limit(15)

    if (data) setHistorico(data)
  }, [supabase, router])

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    carregarHistorico()
  }, [carregarHistorico])

  useEffect(() => {
    if (!userId) return
    const channel = supabase
      .channel('lancamento-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'transactions', filter: `user_id=eq.${userId}` }, () => { carregarHistorico() })
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId])

  // Trocar tipo e categoria juntos — sem useEffect
  function handleSetTipo(t: 'debito' | 'credito') {
    setTipo(t)
    setCategoria(t === 'debito' ? 'Alimentação' : 'Salário')
  }

  function aplicarAtalho(atalho: typeof ATALHOS[0]) {
    handleSetTipo(atalho.tipo as 'debito' | 'credito')
    setDescricao(atalho.label)
    setCategoria(atalho.cat)
  }

  function formatarValor(raw: string) {
    const numeros = raw.replace(/\D/g, '')
    if (!numeros) return ''
    const numero = parseInt(numeros) / 100
    return numero.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  }

  function valorNumerico() {
    return parseFloat(valor.replace(/\./g, '').replace(',', '.')) || 0
  }

  async function salvar(e: React.FormEvent) {
    e.preventDefault()
    setErro('')
    const v = valorNumerico()
    if (!v || v <= 0) { setErro('Digite um valor válido'); return }
    if (!descricao.trim()) { setErro('Digite uma descrição'); return }

    setSalvando(true)
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return

    const { error } = await supabase.from('transactions').insert({
      user_id: user.id,
      descricao: descricao.trim(),
      valor: tipo === 'debito' ? -v : v,
      tipo,
      categoria,
      data_hora: inputParaUTC(dataHora, timezone),
      origem:   'manual',
      conta_id: contaSelecionada || null,
    })

    if (error) { setErro('Erro ao salvar: ' + error.message); setSalvando(false); return }

    setSalvando(false)
    setSucesso(true)
    setValor('')
    setDescricao('')
    setDataHora(dataLocalParaInput(timezone))
    carregarHistorico()
    setTimeout(() => setSucesso(false), 2500)
  }

  async function handleUpload(arquivo: File) {
    if (!arquivo) return
    if (arquivo.size > 10 * 1024 * 1024) { setErro('Arquivo muito grande. Máx 10MB'); return }

    setProcessan(true)
    setTransacoesDetectadas([])
    setErro('')

    const form = new FormData()
    form.append('arquivo', arquivo)

    const res = await fetch('/api/lancamento/upload', { method: 'POST', body: form })
    const data = await res.json()

    setProcessan(false)

    if (!data.ok || !data.transacoes?.length) {
      setErro(data.error || 'Não foi possível extrair transações do documento')
      return
    }

    setTransacoesDetectadas(data.transacoes)
    setResumo(data.resumo || `${data.transacoes.length} transações encontradas`)

    if (data.banco_id) {
      const bancoDados = await (await fetch('/api/bancos')).json()
      const banco = bancoDados.bancos?.find((b: { id: string }) => b.id === data.banco_id)
      if (banco) {
        setBancoDetectado(banco)
        const contasBanco = contas.filter(c => c.bancos?.id === banco.id)
        if (contasBanco.length === 1) setContaUpload(contasBanco[0].id)
      }
    }
  }

  function editarTransacao(i: number, campo: string, valor: string) {
    setTransacoesDetectadas(prev => prev.map((t, idx) => idx === i ? { ...t, [campo]: valor } : t))
  }

  function removerTransacao(i: number) {
    setTransacoesDetectadas(prev => prev.filter((_, idx) => idx !== i))
  }

  async function confirmarLancamentos() {
    setConfirman(true)
    const res = await fetch('/api/lancamento/confirmar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transacoes: transacoesDetectadas, conta_id: contaUpload || null }),
    })
    const data = await res.json()
    setConfirman(false)

    if (data.ok) {
      setTransacoesDetectadas([])
      setResumo('')
      setBancoDetectado(null)
      setContaUpload('')
      setSucesso(true)
      carregarHistorico()
      setTimeout(() => setSucesso(false), 3000)
    } else {
      setErro(data.error || 'Erro ao confirmar')
    }
  }

  async function deletar(id: string) {
    setDeletando(id)
    await supabase.from('transactions').delete().eq('id', id)
    setDeletando(null)
    carregarHistorico()
  }

  const categorias = tipo === 'debito' ? CATEGORIAS_DESPESA : CATEGORIAS_RECEITA

  return (
    <div style={{ minHeight: '100vh', background: '#0a0a0a', fontFamily: 'system-ui, sans-serif', fontSize: 13, color: '#fff' }}>

      <div style={{ display: 'flex', alignItems: 'center', padding: '.875rem 1.5rem', borderBottom: '1px solid #1a3a1a', background: '#0a1a0a', gap: 12 }}>
        <button onClick={() => router.push('/dashboard')} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,.4)', display: 'flex', alignItems: 'center', gap: 5, fontSize: 12 }}>
          <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M9 11L5 7l4-4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
          Dashboard
        </button>
        <span style={{ color: 'rgba(255,255,255,.2)' }}>/</span>
        <span style={{ fontSize: 15, fontWeight: 500 }}>Lançamento</span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '420px 1fr', minHeight: 'calc(100vh - 53px)' }}>

        {/* Formulário */}
        <div style={{ borderRight: '1px solid #1a3a1a', padding: '1.5rem', overflowY: 'auto' }}>

          <div style={{ display: 'flex', background: 'rgba(0,0,0,.4)', border: '1px solid #1a3a1a', borderRadius: 12, padding: 4, marginBottom: '1.5rem' }}>
            {(['debito', 'credito'] as const).map(t => (
              <button key={t} onClick={() => handleSetTipo(t)} style={{
                flex: 1, padding: '10px', borderRadius: 9, border: 'none', cursor: 'pointer',
                fontWeight: 600, fontSize: 13, transition: 'all .2s',
                background: tipo === t ? (t === 'debito' ? 'rgba(239,68,68,.2)' : 'rgba(22,163,74,.2)') : 'transparent',
                color: tipo === t ? (t === 'debito' ? '#f87171' : '#4ade80') : 'rgba(255,255,255,.3)',
                borderBottom: tipo === t ? `2px solid ${t === 'debito' ? '#f87171' : '#4ade80'}` : '2px solid transparent',
              }}>
                {t === 'debito' ? '↓ Despesa' : '↑ Receita'}
              </button>
            ))}
          </div>

          <div style={{ marginBottom: '1.5rem', textAlign: 'center' }}>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.08em', marginBottom: 8 }}>Valor</div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
              <span style={{ fontSize: 22, color: 'rgba(255,255,255,.3)', fontWeight: 300 }}>R$</span>
              <input type="text" inputMode="numeric" value={valor}
                onChange={e => setValor(formatarValor(e.target.value))} placeholder="0,00"
                style={{ background: 'transparent', border: 'none', outline: 'none', fontSize: 42, fontWeight: 700, textAlign: 'center', color: tipo === 'debito' ? '#f87171' : '#4ade80', width: 220 }}
              />
            </div>
            <div style={{ height: 2, background: tipo === 'debito' ? 'rgba(248,113,113,.3)' : 'rgba(74,222,128,.3)', borderRadius: 1, margin: '8px auto 0', width: 200 }} />
          </div>

          <div style={{ marginBottom: '1.25rem' }}>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,.35)', textTransform: 'uppercase', letterSpacing: '.08em', marginBottom: 8 }}>Atalhos rápidos</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {ATALHOS.filter(a => a.tipo === tipo).map(a => (
                <button key={a.label} onClick={() => aplicarAtalho(a)} style={{
                  padding: '5px 12px', borderRadius: 20, border: `1px solid ${CORES[a.cat] || '#1a3a1a'}22`,
                  background: descricao === a.label ? `${CORES[a.cat]}22` : 'rgba(255,255,255,.04)',
                  color: descricao === a.label ? CORES[a.cat] || '#fff' : 'rgba(255,255,255,.5)',
                  fontSize: 11, cursor: 'pointer', transition: 'all .15s',
                }}>{a.label}</button>
              ))}
            </div>
          </div>

          <form onSubmit={salvar}>
            <div style={{ marginBottom: 12 }}>
              <label style={{ display: 'block', fontSize: 10, fontWeight: 500, color: 'rgba(255,255,255,.4)', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.05em' }}>Descrição</label>
              <input value={descricao} onChange={e => setDescricao(e.target.value)} placeholder="Ex: Almoço, Gasolina, Netflix..." required
                style={{ width: '100%', padding: '9px 12px', background: '#111', border: '1px solid #1a3a1a', borderRadius: 8, color: '#fff', fontSize: 13, outline: 'none' }} />
            </div>

            <div style={{ marginBottom: 12 }}>
              <label style={{ display: 'block', fontSize: 10, fontWeight: 500, color: 'rgba(255,255,255,.4)', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.05em' }}>Categoria</label>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {categorias.map(c => (
                  <button key={c} type="button" onClick={() => setCategoria(c)} style={{
                    padding: '5px 12px', borderRadius: 20, border: `1px solid ${categoria === c ? CORES[c] || '#4ade80' : '#1a3a1a'}`,
                    background: categoria === c ? `${CORES[c] || '#4ade80'}18` : 'transparent',
                    color: categoria === c ? CORES[c] || '#4ade80' : 'rgba(255,255,255,.4)',
                    fontSize: 11, cursor: 'pointer', transition: 'all .15s', fontWeight: categoria === c ? 500 : 400,
                  }}>{c}</button>
                ))}
              </div>
            </div>

            {contas.length > 0 && (
              <div style={{ marginBottom: 12 }}>
                <label style={{ display: 'block', fontSize: 10, fontWeight: 500, color: 'rgba(255,255,255,.4)', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.05em' }}>Conta (opcional)</label>
                <select
                  value={contaSelecionada}
                  onChange={e => setConta(e.target.value)}
                  style={{ width: '100%', padding: '9px 12px', background: '#111', border: '1px solid #1a3a1a', borderRadius: 8, color: '#fff', fontSize: 13, outline: 'none', cursor: 'pointer' }}
                >
                  <option value="">Sem conta específica</option>
                  {contas.map(c => (
                    <option key={c.id} value={c.id}>
                      {c.bancos?.nome_curto || '—'} · {c.nome} ({c.tipo})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div style={{ marginBottom: 12 }}>
              <label style={{ display: 'block', fontSize: 10, fontWeight: 500, color: 'rgba(255,255,255,.4)', marginBottom: 5, textTransform: 'uppercase', letterSpacing: '.05em' }}>Data e hora</label>
              <input type="datetime-local" value={dataHora} onChange={e => setDataHora(e.target.value)}
                style={{ width: '100%', padding: '9px 12px', background: '#111', border: '1px solid #1a3a1a', borderRadius: 8, color: '#fff', fontSize: 13, outline: 'none' }} />
            </div>

            <div onClick={() => setRecorrente(!recorrente)} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '1.25rem', padding: '10px 12px', background: '#111', border: '1px solid #1a3a1a', borderRadius: 8, cursor: 'pointer' }}>
              <div style={{ width: 18, height: 18, borderRadius: 4, border: `1.5px solid ${recorrente ? '#16a34a' : '#1a3a1a'}`, background: recorrente ? '#16a34a' : 'transparent', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, transition: 'all .15s' }}>
                {recorrente && <svg width="10" height="10" viewBox="0 0 10 10" fill="none"><polyline points="1.5,5 4,7.5 8.5,2" stroke="#fff" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>}
              </div>
              <div>
                <div style={{ fontSize: 12, fontWeight: 500 }}>Lançamento recorrente</div>
                <div style={{ fontSize: 10, color: 'rgba(255,255,255,.35)' }}>Marcar como gasto fixo mensal</div>
              </div>
            </div>

            {erro && <div style={{ background: 'rgba(239,68,68,.1)', border: '1px solid rgba(239,68,68,.3)', borderRadius: 8, padding: '8px 12px', fontSize: 12, color: '#f87171', marginBottom: 12 }}>{erro}</div>}
            {sucesso && (
              <div style={{ background: 'rgba(74,222,128,.1)', border: '1px solid rgba(74,222,128,.3)', borderRadius: 8, padding: '8px 12px', fontSize: 12, color: '#4ade80', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
                <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><polyline points="2,7 5.5,10.5 12,3" stroke="#4ade80" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
                Lançamento salvo com sucesso!
              </div>
            )}

            <button type="submit" disabled={salvando} style={{
              width: '100%', padding: 13,
              background: tipo === 'debito' ? 'rgba(239,68,68,.2)' : '#16a34a',
              border: `1px solid ${tipo === 'debito' ? 'rgba(239,68,68,.4)' : '#16a34a'}`,
              borderRadius: 10, color: tipo === 'debito' ? '#f87171' : '#fff',
              fontSize: 14, fontWeight: 600, cursor: salvando ? 'default' : 'pointer', opacity: salvando ? 0.6 : 1, transition: 'all .15s',
            }}>
              {salvando ? 'Salvando...' : `Lançar ${tipo === 'debito' ? 'despesa' : 'receita'}${valor ? ' de R$ ' + valor : ''}`}
            </button>
          </form>

          {/* Seção upload */}
          <div style={{ marginTop: '2rem', borderTop: '1px solid #1a3a1a', paddingTop: '1.5rem' }}>
            <div style={{ fontSize: 14, fontWeight: 500, marginBottom: 4 }}>📎 Importar documento</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,.4)', marginBottom: 12 }}>
              Foto de cupom, nota fiscal, fatura PDF ou extrato CSV
            </div>

            <div
              onClick={() => inputRef.current?.click()}
              onDragOver={e => { e.preventDefault(); setDragOver(true) }}
              onDragLeave={() => setDragOver(false)}
              onDrop={e => { e.preventDefault(); setDragOver(false); handleUpload(e.dataTransfer.files[0]) }}
              style={{
                border: `2px dashed ${dragOver ? '#4ade80' : '#1a3a1a'}`,
                borderRadius: 12, padding: '1.5rem',
                textAlign: 'center', cursor: 'pointer',
                background: dragOver ? 'rgba(74,222,128,.05)' : 'transparent',
                transition: 'all .2s',
              }}
            >
              <div style={{ fontSize: 32, marginBottom: 8 }}>📄</div>
              <div style={{ fontSize: 13, color: 'rgba(255,255,255,.5)' }}>
                Clique ou arraste o arquivo aqui
              </div>
              <div style={{ fontSize: 11, color: 'rgba(255,255,255,.3)', marginTop: 4 }}>
                JPG, PNG, PDF, CSV — máx 10MB
              </div>
              <input
                ref={inputRef}
                type="file"
                accept=".jpg,.jpeg,.png,.webp,.pdf,.csv"
                style={{ display: 'none' }}
                onChange={e => e.target.files?.[0] && handleUpload(e.target.files[0])}
              />
            </div>

            {processando && (
              <div style={{ marginTop: 12, padding: '12px', background: '#111', border: '1px solid #1a3a1a', borderRadius: 8, fontSize: 12, color: '#4ade80', display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ animation: 'spin 1s linear infinite' }}>⏳</div>
                Analisando documento com IA...
                <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
              </div>
            )}

            {transacoesDetectadas.length > 0 && !processando && (
              <div style={{ marginTop: 12 }}>
                <div style={{ fontSize: 13, fontWeight: 500, marginBottom: 8, color: '#4ade80' }}>
                  ✅ {resumoDetectado} — Revise antes de confirmar:
                </div>

                {bancoDetectado && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: '#0a1a0a', border: '1px solid #1a3a1a', borderRadius: 8, marginBottom: 12 }}>
                    <div style={{ width: 24, height: 24, borderRadius: 4, background: bancoDetectado.cor || '#4ade80', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#fff', flexShrink: 0 }}>
                      {bancoDetectado.nome_curto[0]}
                    </div>
                    <span style={{ fontSize: 12, color: 'rgba(255,255,255,.7)' }}>
                      Banco detectado: <strong style={{ color: '#fff' }}>{bancoDetectado.nome_curto}</strong>
                    </span>
                  </div>
                )}

                <div style={{ marginBottom: 12 }}>
                  <label style={{ display: 'block', fontSize: 10, fontWeight: 500, color: 'rgba(255,255,255,.4)', marginBottom: 5, textTransform: 'uppercase' as const, letterSpacing: '.05em' }}>Vincular à conta</label>
                  <select
                    value={contaUpload}
                    onChange={e => setContaUpload(e.target.value)}
                    style={{ width: '100%', padding: '9px 12px', background: '#111', border: '1px solid #1a3a1a', borderRadius: 8, color: '#fff', fontSize: 13, outline: 'none', cursor: 'pointer' }}
                  >
                    <option value="">Sem conta específica</option>
                    {contas
                      .filter(c => !bancoDetectado || c.bancos?.id === bancoDetectado.id)
                      .map(c => (
                        <option key={c.id} value={c.id}>
                          {c.bancos?.nome_curto || '—'} — {c.nome}
                        </option>
                      ))
                    }
                  </select>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6, maxHeight: 300, overflowY: 'auto' }}>
                  {transacoesDetectadas.map((t, i) => (
                    <div key={i} style={{ background: '#111', border: '1px solid #1a3a1a', borderRadius: 8, padding: '8px 12px', display: 'flex', alignItems: 'center', gap: 10 }}>
                      <button onClick={() => removerTransacao(i)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#f87171', fontSize: 14, flexShrink: 0 }}>✕</button>
                      <div style={{ flex: 1, minWidth: 0 }}>
                        <input
                          value={t.descricao}
                          onChange={e => editarTransacao(i, 'descricao', e.target.value)}
                          style={{ background: 'transparent', border: 'none', color: '#fff', fontSize: 12, fontWeight: 500, width: '100%', outline: 'none' }}
                        />
                        <div style={{ fontSize: 10, color: 'rgba(255,255,255,.4)' }}>
                          {t.categoria} · {new Date(t.data_hora).toLocaleDateString('pt-BR')}
                        </div>
                      </div>
                      <div style={{ fontSize: 13, fontWeight: 600, color: t.tipo === 'credito' ? '#4ade80' : '#f87171', whiteSpace: 'nowrap' }}>
                        {t.tipo === 'credito' ? '+' : '-'}R$ {Math.abs(t.valor).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
                  <button onClick={() => { setTransacoesDetectadas([]); setBancoDetectado(null); setContaUpload('') }} style={{ flex: 1, padding: '10px', background: 'transparent', border: '1px solid #1a3a1a', borderRadius: 8, color: 'rgba(255,255,255,.4)', fontSize: 13, cursor: 'pointer' }}>
                    Cancelar
                  </button>
                  <button onClick={confirmarLancamentos} disabled={confirmando} style={{ flex: 2, padding: '10px', background: '#16a34a', border: 'none', borderRadius: 8, color: '#fff', fontSize: 13, fontWeight: 600, cursor: confirmando ? 'default' : 'pointer', opacity: confirmando ? 0.7 : 1 }}>
                    {confirmando ? 'Lançando...' : `Confirmar ${transacoesDetectadas.length} lançamento${transacoesDetectadas.length > 1 ? 's' : ''}`}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Histórico */}
        <div style={{ padding: '1.5rem', overflowY: 'auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1rem' }}>
            <div style={{ fontSize: 14, fontWeight: 500 }}>Lançamentos recentes</div>
            <button onClick={() => router.push('/dashboard/gastos')} style={{ fontSize: 11, color: '#4ade80', background: 'none', border: 'none', cursor: 'pointer' }}>ver todos →</button>
          </div>

          {historico.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '3rem', color: 'rgba(255,255,255,.3)', fontSize: 13 }}>
              <div style={{ fontSize: 32, marginBottom: 12 }}>📋</div>
              Nenhum lançamento ainda.<br />Use o formulário ao lado para começar.
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {historico.map(t => (
                <div key={t.id} style={{ background: '#111', border: '1px solid #1a3a1a', borderRadius: 10, padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 12 }}
                  onMouseEnter={e => (e.currentTarget.style.borderColor = '#1a5a1a')}
                  onMouseLeave={e => (e.currentTarget.style.borderColor = '#1a3a1a')}
                >
                  <div style={{ width: 36, height: 36, borderRadius: 10, flexShrink: 0, background: `${CORES[t.categoria] || '#6b7280'}18`, border: `1px solid ${CORES[t.categoria] || '#6b7280'}33`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: CORES[t.categoria] || '#6b7280' }} />
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span style={{ fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.descricao}</span>
                      {t.origem === 'manual' && <span style={{ fontSize: 9, background: 'rgba(255,255,255,.07)', color: 'rgba(255,255,255,.35)', padding: '1px 5px', borderRadius: 3, flexShrink: 0 }}>manual</span>}
                      {t.origem === 'webhook' && <span style={{ fontSize: 9, background: 'rgba(74,222,128,.1)', color: '#4ade80', padding: '1px 5px', borderRadius: 3, flexShrink: 0 }}>auto</span>}
                    </div>
                    <div style={{ fontSize: 10, color: 'rgba(255,255,255,.35)', marginTop: 2 }}>{t.categoria} · {fmtDataHora(t.data_hora)}</div>
                  </div>
                  <div style={{ fontSize: 14, fontWeight: 600, color: t.tipo === 'credito' ? '#4ade80' : '#f87171', whiteSpace: 'nowrap' }}>
                    {t.tipo === 'credito' ? '+' : '-'}{fmtBRL(Math.abs(t.valor))}
                  </div>
                  <button onClick={() => deletar(t.id)} disabled={deletando === t.id} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'rgba(255,255,255,.2)', padding: 4, flexShrink: 0, opacity: deletando === t.id ? 0.4 : 1 }}
                    onMouseEnter={e => (e.currentTarget.style.color = '#f87171')}
                    onMouseLeave={e => (e.currentTarget.style.color = 'rgba(255,255,255,.2)')}
                  >
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 4h10M5 4V3a1 1 0 011-1h2a1 1 0 011 1v1M6 7v3M8 7v3M3 4l1 7a1 1 0 001 1h4a1 1 0 001-1l1-7" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/></svg>
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}